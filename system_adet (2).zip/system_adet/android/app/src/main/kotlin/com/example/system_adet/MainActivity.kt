package com.example.system_adet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
