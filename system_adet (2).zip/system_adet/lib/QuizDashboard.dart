import 'package:flutter/material.dart';
import 'package:system_adet/AnswerQuiz.dart';
import 'create_quiz.dart';

class QuizDashboard extends StatefulWidget {
  final String username;
  final List<Map<String, dynamic>> quizzes;

  QuizDashboard({Key? key, required this.username, required this.quizzes})
      : super(key: key);

  @override
  _QuizDashboardState createState() => _QuizDashboardState();
}

class _QuizDashboardState extends State<QuizDashboard> {
  void navigateToAnswerQuiz(Map<String, dynamic> quiz) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => AnswerQuiz(quiz: quiz)),
    );
  }

  void deleteQuiz(int index) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Delete Quiz"),
        content: Text("Are you sure you want to delete this quiz?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          TextButton(
            onPressed: () {
              setState(() {
                widget.quizzes.removeAt(index);
              });
              Navigator.pop(context);
            },
            child: Text("Delete", style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Quiz Dashboard - ${widget.username}")),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue, Colors.purple], // Customize gradient colors
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            children: [
              ElevatedButton(
                onPressed: () async {
                  final newQuiz = await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => CreateQuiz()),
                  );
                  if (newQuiz != null) {
                    setState(() {
                      widget.quizzes.add(newQuiz);
                    });
                  }
                },
                child: Text("Create New Quiz"),
                style: ElevatedButton.styleFrom(
                  primary: Colors.purple, // Button color
                  padding: EdgeInsets.symmetric(vertical: 15, horizontal: 50),
                  textStyle: TextStyle(fontSize: 16),
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: ListView.builder(
                  itemCount: widget.quizzes.length,
                  itemBuilder: (context, index) {
                    return Card(
                      margin: EdgeInsets.symmetric(vertical: 10),
                      elevation: 5,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: ListTile(
                        contentPadding: EdgeInsets.all(16.0),
                        title: Text(
                          widget.quizzes[index]["title"],
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          "Questions: ${widget.quizzes[index]["questions"].length}",
                          style: TextStyle(fontSize: 14),
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: Icon(Icons.play_arrow, color: Colors.blue),
                              onPressed: () =>
                                  navigateToAnswerQuiz(widget.quizzes[index]),
                            ),
                            IconButton(
                              icon: Icon(Icons.delete, color: Colors.red),
                              onPressed: () => deleteQuiz(index),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
