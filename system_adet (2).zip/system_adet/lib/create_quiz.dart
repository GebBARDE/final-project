import 'package:flutter/material.dart';

class CreateQuiz extends StatefulWidget {
  @override
  _CreateQuizState createState() => _CreateQuizState();
}

class _CreateQuizState extends State<CreateQuiz> {
  final TextEditingController titleController = TextEditingController();
  final List<Map<String, String>> questions = [];

  void addQuestion() {
    questions.add({"question": "", "answer": ""});
    setState(() {});
  }

  void saveQuiz() {
    if (titleController.text.isNotEmpty && questions.isNotEmpty) {
      Navigator.pop(context, {
        "title": titleController.text,
        "questions": questions,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("Create Quiz", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.blueAccent,
        elevation: 5,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Futuristic Title Input
            TextField(
              controller: titleController,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Quiz Title",
                labelStyle: TextStyle(color: Colors.white54),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.blueAccent, width: 2),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.white24, width: 1),
                ),
                filled: true,
                fillColor: Colors.black12,
              ),
            ),
            SizedBox(height: 20),

            // Futuristic Add Question Button
            ElevatedButton(
              onPressed: addQuestion,
              style: ElevatedButton.styleFrom(
                primary: Colors.blueAccent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                elevation: 10,
              ),
              child: Text(
                "Add Question",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBox(height: 20),

            // List of Questions
            Expanded(
              child: ListView.builder(
                itemCount: questions.length,
                itemBuilder: (context, index) {
                  return Card(
                    color: Colors.black45,
                    margin: EdgeInsets.symmetric(vertical: 10),
                    elevation: 5,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Padding(
                      padding: EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Question Input
                          TextField(
                            onChanged: (value) =>
                                questions[index]["question"] = value,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: "Question ${index + 1}",
                              labelStyle: TextStyle(color: Colors.white54),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(
                                    color: Colors.blueAccent, width: 2),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide:
                                    BorderSide(color: Colors.white24, width: 1),
                              ),
                              filled: true,
                              fillColor: Colors.black26,
                            ),
                          ),
                          SizedBox(height: 10),

                          // Answer Input
                          TextField(
                            onChanged: (value) =>
                                questions[index]["answer"] = value,
                            style: TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              labelText: "Answer",
                              labelStyle: TextStyle(color: Colors.white54),
                              focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide(
                                    color: Colors.blueAccent, width: 2),
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide:
                                    BorderSide(color: Colors.white24, width: 1),
                              ),
                              filled: true,
                              fillColor: Colors.black26,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),

            // Futuristic Save Button
            ElevatedButton(
              onPressed: saveQuiz,
              style: ElevatedButton.styleFrom(
                primary: Colors.blueAccent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                elevation: 10,
              ),
              child: Text(
                "Save Quiz",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
