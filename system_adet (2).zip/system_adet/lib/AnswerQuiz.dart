import 'package:flutter/material.dart';

class AnswerQuiz extends StatefulWidget {
  final Map<String, dynamic> quiz;

  AnswerQuiz({Key? key, required this.quiz}) : super(key: key);

  @override
  _AnswerQuizState createState() => _AnswerQuizState();
}

class _AnswerQuizState extends State<AnswerQuiz> {
  final List<String> userAnswers = [];
  int currentQuestionIndex = 0;
  int score = 0;

  void submitAnswer(String answer) {
    setState(() {
      userAnswers.add(answer);
      if (answer.toLowerCase() ==
          widget.quiz["questions"][currentQuestionIndex]["answer"]
              .toLowerCase()) {
        score++;
      }
      if (currentQuestionIndex < widget.quiz["questions"].length - 1) {
        currentQuestionIndex++;
      } else {
        showResults();
      }
    });
  }

  void showResults() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.black87,
        title: Text("Quiz Completed!", style: TextStyle(color: Colors.white)),
        content: Text(
          "Your Score: $score / ${widget.quiz["questions"].length}",
          style: TextStyle(color: Colors.white70),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: Colors.blueAccent)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final question = widget.quiz["questions"][currentQuestionIndex];

    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text(
          widget.quiz["title"],
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.blueAccent,
        elevation: 5,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Display the current question
            Text(
              "Question ${currentQuestionIndex + 1}: ${question["question"]}",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            SizedBox(height: 20),

            // Input for the answer
            TextField(
              onSubmitted: submitAnswer,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Your Answer",
                labelStyle: TextStyle(color: Colors.white54),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.blueAccent, width: 2),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.white24, width: 1),
                ),
                filled: true,
                fillColor: Colors.black12,
              ),
            ),
            SizedBox(height: 20),

            // Submit Button
            ElevatedButton(
              onPressed: () => submitAnswer(
                  'your-answer-here'), // You can call it directly or provide a UI to get the input.
              style: ElevatedButton.styleFrom(
                primary: Colors.blueAccent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                elevation: 10,
              ),
              child: Text(
                "Submit Answer",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
